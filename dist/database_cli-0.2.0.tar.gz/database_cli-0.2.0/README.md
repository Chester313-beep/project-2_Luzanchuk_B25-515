﻿# Database CLI

Простая реляционная база данных с CLI интерфейсом.

## Установка

```bash
pip install database-cli

## Использование

```bash
database
