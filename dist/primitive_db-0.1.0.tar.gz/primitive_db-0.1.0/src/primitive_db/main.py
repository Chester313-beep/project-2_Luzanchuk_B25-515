﻿#!/usr/bin/env python3

def main():
    print("DB project is running!")
    return 0

if __name__ == "__main__":
    exit(main())
